java -jar tracer2.jar $1 $2
